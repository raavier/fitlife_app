# fittrack-domain

Módulo de domínio (lógica pura, sem UI) do app fitness + testes com Vitest.

## Estrutura
- `src/domain/types.ts` — tipos e enum canônico de músculos.
- `src/domain/muscleData.ts` — janelas de recuperação, mapa de esportes, alvos de volume.
- `src/domain/stimulus.ts` — converte exercícios/atividades em estímulos (ativação indireta).
- `src/domain/volume.ts` — volume semanal por músculo + status vs alvo.
- `src/domain/recovery.ts` — fadiga por músculo, status (verde/amarelo/vermelho) e horas até liberar.
- `src/domain/__tests__/` — testes de volume e recuperação.

## Rodar
```
npm install
npm test
```

## Notas de modelagem (ajustáveis)
- Recuperação: `estresse()` mistura volume (satura em ~8 séries efetivas) e RPE; `horasRecuperacao()`
  interpola entre min/max da janela do músculo. Ajuste as constantes conforme sua resposta real.
- Fadiga acumula estímulos recentes (sessões próximas empilham), limitada a 1.0.
- Limiares de status em `recovery.ts`: LIMIAR_RECUPERANDO=0.33, LIMIAR_FADIGADO=0.66.
- Atividades extras e corrida entram pelo mesmo caminho (Estimulo), então já contam no heatmap.
